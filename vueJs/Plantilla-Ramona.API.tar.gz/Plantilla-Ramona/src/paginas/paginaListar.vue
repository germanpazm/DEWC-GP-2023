<script setup>
import contenido from '../components/contenido.vue'
</script>

<template>
    <div>
        <h1>Página Listar</h1>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        
        <contenido parametro="x"/>

    </div>
</template>

<style scoped>

</style>