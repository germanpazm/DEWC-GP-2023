<script setup>
import cabecera from './components/cabecera.vue'
import cuerpo from './components/cuerpo.vue'
</script>

<template>
  <header>
    <cabecera titulo="Aplicacion" contenido="Esta web es desarrollado por" />
  </header>
  <hr>

  <main>
    <cuerpo />

  </main>
</template>

<style scoped>  
</style>

