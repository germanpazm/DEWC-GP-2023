<script setup>

</script>

<template>
    <div>
       <h1>avfaedvfks</h1>
        <h2>Aqui iria la imagen</h2>

    </div>
</template>

<style scoped>

</style>