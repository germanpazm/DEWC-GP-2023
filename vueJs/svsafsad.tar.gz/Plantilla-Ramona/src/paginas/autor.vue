<script setup>

</script>

<template>
    <div>
       <h1>Autor</h1>
        

    </div>
</template>

<style scoped>

</style>