<script setup>

</script>

<template>
    <div>
        <h1>Página Principal</h1>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        <div>fasdfasdfasdfasdfasdfasdfasdfasdffa </div>
        

    </div>
</template>

<style scoped>

</style>